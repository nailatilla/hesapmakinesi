
# Vergi Hesaplayıcı

Bu basit web uygulaması, KDV dahil bir tutarı girerek:
- KDV matrahını
- KDV tutarını
- %25 gelir vergisini
- Gelir vergisi düşülmüş net tutarı

hesaplar ve kullanıcıya gösterir.

## Kullanım

1. `index.html` dosyasını bir web tarayıcısında açabilirsiniz  
2. Veya bu projeyi GitHub Pages ile yayınlayarak internet üzerinden herkes erişebilir

## GitHub Pages ile Yayınlama

1. Bu projeyi kendi GitHub hesabına klonla
2. Reponun ayarlarına git (Settings → Pages)
3. “Source” bölümünde `main` branch ve `/root` klasörünü seç
4. Sayfanız şu şekilde yayınlanır:  
   `https://kullaniciadi.github.io/vergi-hesaplayici/`
